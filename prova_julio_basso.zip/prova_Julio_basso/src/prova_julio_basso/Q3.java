/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_julio_basso;

import javax.swing.JOptionPane;

/**
 *
 * @author jbasso
 */
public class Q3 {
     public static void main(String[] args) {
         String s = "";
         int resultado= 0,i=0;
         float total=0,ca1=0,ca2=0,ca3=0;
         float total1=0,total2=0,total3=0;
         do{
         s=JOptionPane.showInputDialog(null,"Digite 1 - café expresso; 2 - café capuccino; 3 - leite com café; 4 - totalizar vendas;");
         i=Integer.parseInt(s);
         if(i == 1){
             total1 = (float) (total1 + 0.75);
             ca1++;
         }else if (i==2){
             total2 = total2+1;
             ca2++;
         
         }else if (i==3){
             total3 = (float) (total3 + 1.25);
             ca3++;
         }
         total=total1+total2+total3;
         if(i!=4){
         JOptionPane.showMessageDialog(null, "Deseja continuar Operando Digite 4 para fechar \nSua fatura esta em: "+total);
         }
         }while(i!=4);
         
         JOptionPane.showMessageDialog(null, "A quantidade vendida de 1 - café expresso e: "+ca1+" valor Total: "+total1+"R$\n"
                 + "A quantidade vendida de 2 - café capuccino e: "+ca2+" valor Total: "+total2+"R$\n"
                         + "A quantidade vendida de 3 - leite com café e: "+ca3+" valor Total: "+total3+"R$\n"
                                 + "O total geral do dia e: "+total+"R$");
         
         
              
     }
    
    
}
