/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_julio_basso;

import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author jbasso
 */
public class Q9 {
    public static void main(String[] args) throws IOException {
        String nome, s= "";
        float peso=0;
        DataInputStream dados;
        System.out.println("Digite o nome do lutador ");
        dados = new DataInputStream(System.in);
        nome=dados.readLine();
        System.out.println("Digite o peso do lutador");
        dados = new DataInputStream(System.in);
        s=dados.readLine();
        peso=Float.parseFloat(s);
        FileWriter arq = new FileWriter("C:\\Users\\jbasso\\Desktop\\Lutador.txt");
        PrintWriter gravaArq = new PrintWriter(arq);
        gravaArq.print("\nLutador\n");
        if(peso>99 ){
            gravaArq.print("Nome Fornecido: "+nome+"\n Peso Fornecido: "+peso+"\n"
                    + "O lutador "+nome+" pesa "+peso+"KG e se Enquadra na categoria Pesado ");
            
        }else if (peso>92){
            gravaArq.print("Nome Fornecido: "+nome+"\n Peso Fornecido: "+peso+"\n"
                    + "O lutador "+nome+" pesa "+peso+"KG e se Enquadra na categoria Meio pesado ");
        
        }else if (peso>85){
            gravaArq.print("Nome Fornecido: "+nome+"\n Peso Fornecido: "+peso+"\n"
                    + "O lutador "+nome+" pesa "+peso+"KG e se Enquadra na categoria Médio ");
        
        }else if (peso>78){
            gravaArq.print("Nome Fornecido: "+nome+"\n Peso Fornecido: "+peso+"\n"
                    + "O lutador "+nome+" pesa "+peso+"KG e se Enquadra na categoria Medio méio ");
        
        }else if (peso>71){
            gravaArq.print("Nome Fornecido: "+nome+"\n Peso Fornecido: "+peso+"\n"
                    + "O lutador "+nome+" pesa "+peso+"KG e se Enquadra na categoria Ligeiro ");
        
        }else if (peso>64){
            gravaArq.print("Nome Fornecido: "+nome+"\n Peso Fornecido: "+peso+"\n"
                    + "O lutador "+nome+" pesa "+peso+"KG e se Enquadra na categoria Leve ");
        
        }else{
            gravaArq.print("Nome Fornecido: "+nome+"\n Peso Fornecido: "+peso+"\n"
                    + "O lutador "+nome+" pesa "+peso+"KG e se Enquadra na categoria Pena ");
        
        }
        arq.close();
        System.out.println("Salvo com sucesso");
    }
    
}
