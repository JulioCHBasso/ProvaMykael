/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_julio_basso;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 *
 * @author jbasso
 */
public class Q8 {
    public static void main(String[] args) throws IOException {
        int i,n = 0;
       
        Scanner ler= new Scanner(System.in);
        System.out.println("Digite um valor para salvar a tabuada");
        n=ler.nextInt();
        FileWriter arq = new FileWriter("C:\\Users\\jbasso\\Desktop\\Tabuada"+n+".txt");
        PrintWriter gravaArq = new PrintWriter(arq);
        gravaArq.print("-----Tabuada-------");
        for(i=0;i<10;i++){
        gravaArq.print("\n"+n+" X "+i+" = "+(n*i)+"\n");
        }
        arq.close();
        System.out.println("Salvo com sucesso no endereço C:\\Users\\jbasso\\Desktop\\Tabuada"+n+".txt\" ");
       
    }
    
}
