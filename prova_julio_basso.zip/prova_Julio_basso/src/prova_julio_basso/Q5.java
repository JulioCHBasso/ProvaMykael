/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_julio_basso;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author jbasso
 */
public class Q5 {
    public static void main(String[] args) throws IOException {
        String s="";
        int codUsuarioR = 1234,codUsuario=0;
        int senhaR=9999,senha=0;
        DataInputStream dados ;
        System.out.println("Digite o codigo de susuario ");
        dados=new DataInputStream(System.in);
        s=dados.readLine();
        codUsuario = Integer.parseInt(s);
        if(codUsuarioR!=codUsuario){
            System.out.println("Usuario Invalido!!");        
        }else{
            System.out.println("Digite a senha ");
            dados=new DataInputStream(System.in);
            s=dados.readLine();
            senha = Integer.parseInt(s);
            
            if(senhaR != senha ){
                System.out.println("senha incorreta.");
            
            }else{
                System.out.println("Acesso permitido");
            
            }
        }
        
                
    }
}
