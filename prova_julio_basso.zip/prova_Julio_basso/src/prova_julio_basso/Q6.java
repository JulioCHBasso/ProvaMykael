/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_julio_basso;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author jbasso
 */
public class Q6 {
    public static void main(String[] args) throws IOException {
        String s="";
        float n=1,media=0,soma=0,cont=0;
        DataInputStream dados;
        
        while(n!=0){
            System.out.println("Digite um numero para N");
            dados = new DataInputStream(System.in);
            s=dados.readLine();
            n=Float.parseFloat(s);
            if(n != 0){
            cont++;
            soma=soma+n;
            
            System.out.println("Deseja Continuar Digitando numeros \n caso queira sair digite ZERO(0)");
            }
            }
        media = soma/cont;
        System.out.println("A media dos numero digitados e:"+media+"\nA Soma dos numeros digitado é: "+soma+"\nA quantidade de numeros digitado é: "+cont);
        
    }
    
}
