/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_julio_basso;

import javax.swing.JOptionPane;

/**
 *
 * @author jbasso
 */
public class Q4 {
    public static void main(String[] args) {
        String s ="";
        int num;
        s=JOptionPane.showInputDialog(null,"Digite um numero inteiro para podermos ver o antecessor e seu sucessor");
        num=Integer.parseInt(s);
        
        JOptionPane.showMessageDialog(null, "O antecessor do numero "+num+" e: "+(num-1)+"\n"
                + "O sucessor do Numero "+num+" e: "+(num+1));
    }
    
}
