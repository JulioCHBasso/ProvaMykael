/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_julio_basso;

import javax.swing.JOptionPane;

/**
 *
 * @author jbasso
 */
public class Q2 {
    
     public static void main(String[] args) {
        // TODO code application logic here
        String s ="";
        float idadeAno,idadeMes,idadeDia,calIdadeDia=0;
        JOptionPane.showMessageDialog(null,"Digite sua idade em detalhes quantos anos, meses e dias Voce tem de vida ");
        s=JOptionPane.showInputDialog(null, "começando por quantos anos fechados (Periodo de 12 meses)Você tem");
        idadeAno = Float.parseFloat(s);
        s=JOptionPane.showInputDialog(null, "quantos meses Você tem");
        idadeMes = Float.parseFloat(s);
        s=JOptionPane.showInputDialog(null, "Quantos dias você tem");
       idadeDia=Float.parseFloat(s);
       calIdadeDia = idadeAno*365;
       calIdadeDia = calIdadeDia+(idadeMes*30);
       calIdadeDia = calIdadeDia+ idadeDia;
       
       JOptionPane.showMessageDialog(null, "Ano"+idadeAno+" Mes "+idadeMes+" Dia "+idadeDia+"\nResultado: "+calIdadeDia+"Dias");  
        
    }
    
}
